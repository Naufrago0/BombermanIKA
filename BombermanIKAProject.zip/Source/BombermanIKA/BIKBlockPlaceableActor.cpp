#include "BIKBlockPlaceableActor.h"

ABIKBlockPlaceableActor::ABIKBlockPlaceableActor()
{
	LevelBlock = nullptr;
}